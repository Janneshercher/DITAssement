function OpenNAV(){
    document.getElementById("navbarid").style.width = "250px";
}
function CLOSEnavbar(){
    document.getElementById("navbarid").style. width = "0";
}