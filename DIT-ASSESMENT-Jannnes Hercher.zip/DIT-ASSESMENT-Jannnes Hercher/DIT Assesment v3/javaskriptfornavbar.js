function OpenNAV(){
   
    document.getElementById("navbarid").style.width = "250px";
    document.getElementById("main").style.marginLeft = "500px";
document.body.style.backgroundColor = "rgba(0,0,0,0.6)";
backgroundColor = "rgba(0,0,0,0.6)";
document.style.marginLeft = "500px"
}
function CLOSEnavbar(){
    document.getElementById("navbarid").style. width = "0";
    document.getElementById("main").style.marginLeft = "0";
backgroundColor = white
document.body.style.backgroundColor = "white";

}
/*
function makethesizeofpbigger(){
var pElement = document.getElementById("text");
var currentsizeofp = window.getComputedStyle(pElement).fontSize;
var newsizeforp = parseFloat(currentsizeofp) + 2;
pElement.style.fontSize = newsizeforp +"px";
}

function makethesizeofpsmaller(){
   
   var pElement = document.getElementById("text");


var currentsizeofp = window.getComputedStyle(pElement).fontSize;
var newsizeforp = parseFloat(currentsizeofp) - 2;
pElement.style.fontSize = newsizeforp +"px";
}*/